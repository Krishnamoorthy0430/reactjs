import React from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import './App.css';
import LoginPage from './components/login/LoginPage';
import ResidentRegistrationForm from './components/Resident/ResidentRegistrationForm';

function App() {

  return (
        <Routes>
          {/* <Route path="/register-manager" element={ManagerRegistrationForm} />
          <Route path="/register-resident" element={ResidentRegistrationForm} />
          <PrivateRoute path="/manager" roles={['Manager']} />
          <PrivateRoute path="/resident" roles={['Resident']} /> */}
          <Route path="/login" Component={LoginPage} />
          <Route path="*" element={<Navigate to="/" />} />
          <Route path="/register-resident" Component={ResidentRegistrationForm} />
        </Routes>
  );
}

export default App;
