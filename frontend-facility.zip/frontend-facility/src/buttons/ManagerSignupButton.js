import ManagerRegistrationForm from "../components/manager/ManagerRegistrationForm";

const ManagerSignupButton = () => {
    return <div>
        <ManagerRegistrationForm />
    </div>
}
export default ManagerSignupButton;